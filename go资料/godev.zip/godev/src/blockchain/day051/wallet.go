package main

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"log"

	"golang.org/x/crypto/ripemd160"
)

// 计算比特币地址时，使用的版本
const version = byte(0x00)

// 比特币地址校验和的长度
const addressChecksumLen = 4

// 钱包文件名称
const walletFile = "wallet.dat"

// 钱包类型(私钥公钥对)
type Wallet struct {
	PrivateKey ecdsa.PrivateKey //私钥
	PublicKey  []byte           //公钥
}

// 生成私钥公钥对的函数
func newKeyPair() (ecdsa.PrivateKey, []byte) {
	// 1 生成椭圆曲线
	curve := elliptic.P256()
	// 2 根据椭圆曲线和随机值生成一个私钥
	private, err := ecdsa.GenerateKey(curve, rand.Reader)
	if err != nil {
		log.Panic(err)
	}
	// 3 根据私钥生成公钥
	pubkey := append(private.PublicKey.X.Bytes(), private.PublicKey.Y.Bytes()...)
	// 4 返回私钥公钥对
	return *private, pubkey
}

// 创建钱包的函数
func NewWallet() *Wallet {
	private, public := newKeyPair()
	wallet := Wallet{private, public}
	return &wallet
}

// 通过公钥得到公钥Hash(为通过公钥计算地址服务的，编码前的第二部分)
func HashPubKey(pubKey []byte) []byte {
	// 1 先对公钥sha256
	publicSHA256 := sha256.Sum256(pubKey)
	RIPEMD160Hasher := ripemd160.New()
	_, err := RIPEMD160Hasher.Write(publicSHA256[:])
	if err != nil {
		log.Panic(err)
	}
	// 2 二次Hash运算
	publicRIPEMD160 := RIPEMD160Hasher.Sum(nil)
	// 3 返回Hash运算的结果
	return publicRIPEMD160
}

// 校验和，编码前的第三部分
func checksum(payload []byte) []byte {
	firstSHA := sha256.Sum256(payload)
	secondSHA := sha256.Sum256(firstSHA[:])
	return secondSHA[:addressChecksumLen]
}

// 通过钱包获取对应的地址
func (w Wallet) GetAddress() []byte {
	// 1 得到编码前的第二部分
	pubKeyHash := HashPubKey(w.PublicKey)
	// 2 前两部分
	versionedPayload := append([]byte{version}, pubKeyHash...)
	// 3 求第三部分
	checksum := checksum(versionedPayload)
	// 4 将三部分组合成一个[]byte数据
	fullPayload := append(versionedPayload, checksum...)
	// 5 把准备好的数据进行base58编码，得到地址
	address := Base58Encode(fullPayload)
	// 6 返回地址
	return address
}

// 验证地址
func ValidateAddress(address string) bool {
	//将要验证的地址，进行base58解码，得到编码前的三部分数据
	pubKeyHash := Base58Decode([]byte(address))
	// 获取实际地址的校验和
	actualChecksum := pubKeyHash[len(pubKeyHash)-addressChecksumLen:]

	// 获取第一部分，也就是版本信息
	version := pubKeyHash[0]
	// 获取第二部分，也就是公钥Hash
	pubKeyHash = pubKeyHash[1 : len(pubKeyHash)-addressChecksumLen]
	// 计算的校验和
	targetChecksum := checksum(append([]byte{version}, pubKeyHash...))

	//targetChecksum := checksum(pubKeyHash[0 : len(pubKeyHash)-addressChecksumLen])
	// 字节序列比较
	return bytes.Compare(actualChecksum, targetChecksum) == 0

}
