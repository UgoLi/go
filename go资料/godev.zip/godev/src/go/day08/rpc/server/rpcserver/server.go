package rpcserver

import (
	"errors"
)

// 1 参数的类型的定义
type Args struct {
	A, B int
}

// 2 返回值的类型的定义
type Quotient struct {
	Quo, Rem int
}

// 3 远程对象的类型
type Arith int

// 3.1 远程调用的乘法
func (t *Arith) Multiply(args *Args, reply *int) error {
	*reply = args.A * args.B
	return nil
}

// 3.2 远程过程调用的除法
func (t *Arith) Divide(args *Args, quo *Quotient) error {
	if args.B == 0 {
		return errors.New("divide by zero")
	}
	quo.Quo = args.A / args.B
	quo.Rem = args.A % args.B
	return nil
}
