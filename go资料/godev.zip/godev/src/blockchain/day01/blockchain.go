package main

// 区块链的类型
type Blockchain struct {
	blocks []*Block
}

//区块链类型的方法，添加区块
func (bc *Blockchain) AddBlock(data string) {
	// 获取区块链中最近添加的区块
	prevBlock := bc.blocks[len(bc.blocks)-1]
	// 创建一个新块
	newBlock := NewBlock(data, prevBlock.Hash)
	// 将新块添加到区块链中
	bc.blocks = append(bc.blocks, newBlock)

}

// 创建新的包含创世块的区块链
func NewBlockchain() *Blockchain {
	return &Blockchain{[]*Block{NewGenesisBlock()}}
}
