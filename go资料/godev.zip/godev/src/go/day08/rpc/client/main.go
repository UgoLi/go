// main
package main

import (
	"fmt"
	"go/day08/rpc/server/rpcserver"
	"log"
	"net/rpc"
	"time"
)

func main() {
	// 1 连接服务器端
	client, err := rpc.DialHTTP("tcp", "127.0.0.1:1234")
	if err != nil {
		log.Fatal("dialing:", err)
	}
	//准备参数
	args := &rpcserver.Args{15, 10}
	// 准备返回值
	var reply int
	// 2.1 同步调用乘法
	err = client.Call("Arith.Multiply", args, &reply)
	if err != nil {
		log.Fatal("arith error:", err)
	}
	fmt.Printf("Arith:%d*%d=%d\n", args.A, args.B, reply)

	// 准备返回值
	quotient := new(rpcserver.Quotient)
	// 2.2 同步调用除法
	err = client.Call("Arith.Divide", args, quotient)
	if err != nil {
		log.Fatal("arith error:", err)
	}
	fmt.Printf("Arith:%d/%d=%d\n", args.A, args.B, quotient.Quo)
	fmt.Printf("Arith:%d%%%d=%d\n", args.A, args.B, quotient.Rem)
	//3.1 异步调用乘法
	mulCall := client.Go("Arith.Multiply", args, &reply, nil)
	divCall := client.Go("Arith.Divide", args, quotient, nil)
	fmt.Println("不等函数返回，程序直接继续向下执行！")
	for {
		select {
		case r := <-mulCall.Done:
			if r.Error != nil {
				fmt.Println(r.Error)
			} else {
				fmt.Printf("Arith:%d*%d=%d\n", args.A, args.B, reply)
			}
		case r := <-divCall.Done:
			if r.Error != nil {
				fmt.Println(r.Error)
			} else {
				fmt.Printf("Arith:%d/%d=%d\n", args.A, args.B, quotient.Quo)
				fmt.Printf("Arith:%d%%%d=%d\n", args.A, args.B, quotient.Rem)
			}
		default:
			time.Sleep(time.Second)
			fmt.Println("程序正在完成其它任务")
		}
	}

}
