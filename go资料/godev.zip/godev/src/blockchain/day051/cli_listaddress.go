package main

import (
	"fmt"
	"log"
)

func (cli *CLI) listAddresses() {

	// 1 创建钱包集合对象(确保钱包文件是存在的)
	walltes, err := NewWallets()
	if err != nil {
		log.Panic(err)
	}
	// 2 获取钱包所有地址
	addresses := walltes.GetAddresses()
	// 3 打印所有地址
	for _, address := range addresses {
		fmt.Println(address)
	}
}
