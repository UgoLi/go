package main

import (
	"encoding/hex"
	"log"

	"github.com/boltdb/bolt"
)

//用于存储UTXOSet的表的名称
const utxoBucket = "chainstate"

// 定义未花费交易输出集类型
type UTXOSet struct {
	Blockchain *Blockchain
}

// 遍历整个区块链，获取相关的数据构造UTXOSet
// 在创建区块链的同时，就会创建UTXOSet对象，所以在cli的createBlockchain中被调用
func (u UTXOSet) Reindex() {
	// 1 获取数据对象
	db := u.Blockchain.db
	// 2 表的名称(用[]byte)
	bucketName := []byte(utxoBucket)
	// 3 读写事务
	err := db.Update(func(tx *bolt.Tx) error {
		// 3.1 先删除统一名称的现有表
		err := tx.DeleteBucket(bucketName)
		if err != nil && err != bolt.ErrBucketNotFound {
			log.Panic(err)
		}
		// 3.2 创建新表
		_, err = tx.CreateBucket(bucketName)
		if err != nil {
			log.Panic(err)
		}
		return nil

	})
	if err != nil {
		log.Panic(err)
	}
	// 4 获取未花费交易输出(以交易ID为键，未花费交易输出集合为值?)
	// 在区块链类型中实现获取未花费交易输出
	UTXO := u.Blockchain.FindUTXO()
	// 5 将未花费交易输出写到表中
	err = db.Update(func(tx *bolt.Tx) error {
		b := tx.Bucket(bucketName)
		// 遍历UTXO
		for txID, outs := range UTXO {
			key, err := hex.DecodeString(txID)
			if err != nil {
				log.Panic(err)
			}
			// 以交易ID为键，以outs为值保存(?)
			err = b.Put(key, outs.Serialize())
			if err != nil {
				log.Panic(err)
			}
		}
		return nil
	})

}

func (u UTXOSet) Update(block *Block) {
	db := u.Blockchain.db
	// 读写事务
	err := db.Update(func(tx *bolt.Tx) error {
		// 获取表对象
		b := tx.Bucket([]byte(utxoBucket))
		// 遍历新块的交易
		for _, tx := range block.Transactions {
			if tx.IsCoinbase() == false {
				// 遍历交易中的输入
				for _, vin := range tx.Vin {
					updateOuts := TXOutputs{}
					// 根据输入中的交易ID获取相关的未花费交易输出
					outsBytes := b.Get(vin.Txid)
					outs := DeserializeOutputs(outsBytes)
					// 遍历交易的输出
					for outIdx, out := range outs.Outputs {
						// 在被引用的交易中去掉被引用的交易输出
						if outIdx != vin.Vout {
							updateOuts.Outputs = append(updateOuts.Outputs, out)
						}
					}
					if len(updateOuts.Outputs) == 0 {
						err := b.Delete(vin.Txid)
						if err != nil {
							log.Panic(err)
						}
					} else {
						err := b.Put(vin.Txid, updateOuts.Serialize())
						if err != nil {
							log.Panic(err)
						} //if
					} //else

				} //for tx.Vin
			} //if

			// 添加交易带来的新的输出
			newOutputs := TXOutputs{}
			for _, out := range tx.Vout {
				newOutputs.Outputs = append(newOutputs.Outputs, out)
			}
			// 添加新的未花费交易输出
			err := b.Put(tx.ID, newOutputs.Serialize())
			if err != nil {
				log.Panic(err)
			}

		}
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
}

// 获取指定地址的可花费交易输出(为普通交易服务)
func (u UTXOSet) FindSpendableOutputs(pubKeyHash []byte,
	amount int) (int, map[string][]int) {
	unspentOutputs := make(map[string][]int)
	accumulated := 0
	db := u.Blockchain.db

	err := db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(utxoBucket))
		c := b.Cursor()
		for k, v := c.First(); k != nil; k, v = c.Next() {
			txID := hex.EncodeToString(k)
			outs := DeserializeOutputs(v)
			for outIdx, out := range outs.Outputs {
				if out.IsLockedWithKey(pubKeyHash) && accumulated < amount {
					accumulated += out.Value
					unspentOutputs[txID] = append(unspentOutputs[txID], outIdx)
				}
			}
		}
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
	return accumulated, unspentOutputs
}

// 查找指定地址的未花费交易输出
func (u UTXOSet) FindUTXO(pubKeyHash []byte) []TXOutput {
	var UTXOs []TXOutput
	db := u.Blockchain.db
	//只读事务
	err := db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(utxoBucket))
		c := b.Cursor()
		for k, v := c.First(); k != nil; k, v = c.Next() {
			outs := DeserializeOutputs(v)
			for _, out := range outs.Outputs {
				if out.IsLockedWithKey(pubKeyHash) {
					UTXOs = append(UTXOs, out)
				}
			}
		}
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
	return UTXOs
}
