package math2

import (
	"fmt"
)

func Mul(a, b int) int {
	Test()
	return a * b
}
func Test() {
	fmt.Println("test")
}
