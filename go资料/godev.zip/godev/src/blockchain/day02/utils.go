package main

import (
	"bytes"
	"encoding/binary"
	"log"
)

// 将int64转为为字节序列[]byte
func IntToHex(num int64) []byte {
	// 创建一个缓冲区对象
	buff := new(bytes.Buffer)
	// 将num的二进制数据写入到buff对象中
	err := binary.Write(buff, binary.BigEndian, num)
	if err != nil {
		log.Panic(err)
	}
	//返回buff数据的的字节序列
	return buff.Bytes()

}
