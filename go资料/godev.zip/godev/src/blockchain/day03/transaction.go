package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/gob"
	"fmt"
	"log"
)

// 交易类型
type Transaction struct {
	ID   []byte     //交易的Hash值
	Vin  []TXInput  //输入的集合
	Vout []TXOutput //输出的集合
}

//交易输出类型
type TXOutput struct {
	Value        int    //币值
	ScriptPubkey string //地址(钱属于谁的)
}

func (out *TXOutput) CanBeUnlockedWith(unlockingData string) bool {
	return out.ScriptPubkey == unlockingData
}

//交易输入类型(完全引用了交易输出)
type TXInput struct {
	Txid      []byte //引用的输出所对应的交易的ID
	Vout      int    //交易输出在交易中的索引值
	ScriptSig string //地址(钱属于谁的)
}

func (in *TXInput) CanUnlockOutputWith(unlockingData string) bool {
	return in.ScriptSig == unlockingData
}

// 设置交易ID的方法
func (tx *Transaction) SetID() {
	// 定义一个Buff对象
	var endcoded bytes.Buffer
	// 定义一个字节数组
	var hash [32]byte
	//创建一个编码器
	enc := gob.NewEncoder(&endcoded)
	err := enc.Encode(tx)
	if err != nil {
		log.Panic(err)
	}
	// 计算交易的Hash
	hash = sha256.Sum256(endcoded.Bytes())
	// 保存交易Hash
	tx.ID = hash[:]
}

// 创币交易的函数(to代表谁接收奖励)
func NewCoinbaseTX(to, data string) *Transaction {
	if data == "" {
		data = fmt.Sprintf("Reward to '%s'", to)
	}
	txin := TXInput{[]byte{}, -1, data}
	txout := TXOutput{subsidy, to}
	tx := Transaction{nil, []TXInput{txin}, []TXOutput{txout}}
	tx.SetID()
	return &tx
}
