# Blockchain in Go

A blockchain implementation in Go, as described in these articles:

1. [Basic Prototype](https://jeiwan.cc/posts/building-blockchain-in-go-part-1/)
2. [Proof-of-Work](https://jeiwan.cc/posts/building-blockchain-in-go-part-2/)
2. [Persistence and CLI](https://jeiwan.cc/posts/building-blockchain-in-go-part-3/)
3. [Transactions 1](https://jeiwan.cc/posts/building-blockchain-in-go-part-4/)
3. [Addresses](https://jeiwan.cc/posts/building-blockchain-in-go-part-5/)
