// main
package main

import (
	"fmt"
)

func main() {
	// 1 创建包含创世块的区块链
	bc := NewBlockchain()
	// 2 添加新区块
	bc.AddBlock("John send 1 BTC to Tom ")
	bc.AddBlock("zhangsan send 2 btc to lisi")
	bc.AddBlock("张飞 send 2 btc to 刘备")
	// 3 遍历区块链信息
	for index, block := range bc.blocks {
		fmt.Printf("*********区块索引：%d **************\n", index)
		fmt.Printf("上一个区块的Hash：%x\n", block.PrevBlockHash)
		fmt.Printf("交易信息：%s\n", block.Data)
		fmt.Printf("当前块Hash:%x\n\n", block.Hash)
		//fmt.Printf("时间戳：%v\n", block.Timestamp)

	}
	//块的序列化和反序列化
	byteData := bc.blocks[1].Serialize()
	fmt.Println(byteData)
	
	block1 := Deserialize(byteData)
	fmt.Printf("上一个区块的Hash：%x\n", block1.PrevBlockHash)
	fmt.Printf("交易信息：%s\n", block1.Data)
	fmt.Printf("当前块Hash:%x\n\n", block1.Hash)

}
