package main

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"encoding/gob"
	"encoding/hex"
	"fmt"
	"log"
	"math/big"
)

// 交易类型
type Transaction struct {
	ID   []byte     //交易的Hash值
	Vin  []TXInput  //输入的集合
	Vout []TXOutput //输出的集合
}

// 设置交易ID的方法
func (tx *Transaction) SetID() {
	// 定义一个Buff对象
	var endcoded bytes.Buffer
	// 定义一个字节数组
	var hash [32]byte
	//创建一个编码器
	enc := gob.NewEncoder(&endcoded)
	err := enc.Encode(tx)
	if err != nil {
		log.Panic(err)
	}
	// 计算交易的Hash
	hash = sha256.Sum256(endcoded.Bytes())
	// 保存交易Hash
	tx.ID = hash[:]
}

// 创币交易的函数(to代表谁接收奖励)
func NewCoinbaseTX(to, data string) *Transaction {
	if data == "" {
		data = fmt.Sprintf("Reward to '%s'", to)
	}
	// 修改交易输入
	txin := TXInput{[]byte{}, -1, nil, []byte(data)}
	//修改交易输出
	txout := NewTXOutput(subsidy, to)
	tx := Transaction{nil, []TXInput{txin}, []TXOutput{*txout}}
	tx.SetID()
	return &tx
}

//判断是否是创币交易
func (tx Transaction) IsCoinbase() bool {
	return len(tx.Vin) == 1 && len(tx.Vin[0].Txid) == 0 && tx.Vin[0].Vout == -1
}

//普通交易
func NewUTXOTransaction(from, to string, amount int,
	bc *Blockchain) *Transaction {

	var inputs []TXInput
	var outputs []TXOutput

	// 创建一个钱包对象
	wallets, err := NewWallets()
	if err != nil {
		log.Panic(err)
	}
	// 根据地址获取指定的钱包(私钥公钥对)
	wallet := wallets.GetWallet(from)
	// 根据钱包中的公钥，计算公钥Hash
	pubKeyHash := HashPubKey(wallet.PublicKey)
	//第一个参数由address换成了公钥Hash
	acc, validOutputs := bc.FindSpendableOutputs(pubKeyHash, amount)
	if acc < amount {
		log.Panic("ERROR:Not enough funds")
	}
	// 构造交易的输入列表(完全引用了输出)
	for txid, outs := range validOutputs {
		txID, err := hex.DecodeString(txid)
		if err != nil {
			log.Panic(err)
		}
		for _, out := range outs {
			input := TXInput{txID, out, nil, wallet.PublicKey}
			inputs = append(inputs, input)
		}
	}
	// 构造交易输出的列表
	outputs = append(outputs, *NewTXOutput(amount, to))
	//找零机制，发送者也有输出
	if acc > amount {
		outputs = append(outputs, *NewTXOutput(acc-amount, from))
	}
	// 构造交易
	tx := Transaction{nil, inputs, outputs}
	// 计算并保存交易ID
	//tx.SetID()
	tx.ID = tx.Hash()
	// 签名交易
	bc.SignTransaction(&tx, wallet.PrivateKey)

	return &tx

}

// 准备要签名的数据
func (tx *Transaction) TrimmedCopy() Transaction {
	var inputs []TXInput
	var outputs []TXOutput

	// 1 遍历交易输入，只保存需要签名的数据
	for _, vin := range tx.Vin {
		inputs = append(inputs, TXInput{vin.Txid, vin.Vout, nil, nil})
	}
	// 2 遍历交易输出，输出中的数据是我们需要的(币值，接受者)
	for _, vout := range tx.Vout {
		outputs = append(outputs, TXOutput{vout.Value, vout.PubKeyHash})
	}
	// 3 构造要签名的数据
	txCopy := Transaction{tx.ID, inputs, outputs}
	return txCopy
}

// 交易的序列化
func (tx Transaction) Serialize() []byte {
	// 1 创建一个缓冲区
	var encoded bytes.Buffer
	// 2 创建编码器
	enc := gob.NewEncoder(&encoded)
	// 3 对交易进行编码
	err := enc.Encode(tx)
	if err != nil {
		log.Panic(err)
	}
	return encoded.Bytes()
}

// 返回剪切后的交易的Hash(只对剪切后的数据求Hash)
func (tx *Transaction) Hash() []byte {
	var hash [32]byte
	txCopy := *tx
	txCopy.ID = []byte{}
	hash = sha256.Sum256(txCopy.Serialize())
	return hash[:]

}

// 交易签名(需要对交易的每一个输入签名 )
// 参数1：发送者的私钥
// 参数2:当前交易引用的前几笔交易，使用映射表示
func (tx *Transaction) Sign(privKey ecdsa.PrivateKey, prevTXs map[string]Transaction) {
	// 1 创币交易不需要签名
	if tx.IsCoinbase() {
		return
	}
	// 2 判断当前交易引用的前几笔交易是有效的
	for _, vin := range tx.Vin {
		if prevTXs[hex.EncodeToString(vin.Txid)].ID == nil {
			log.Panic("ERROR:引用的前几笔交易无效！")
		}
	}
	// txCopy的有效信息:币值，接受者，还差发送者信息
	txCopy := tx.TrimmedCopy()
	for inID, vin := range tx.Vin {
		//根据映射中的键得到值(值就是交易)
		prevTx := prevTXs[hex.EncodeToString(vin.Txid)]
		txCopy.Vin[inID].Signature = nil
		//保存的是发送者的地址
		txCopy.Vin[inID].PubKey = prevTx.Vout[vin.Vout].PubKeyHash
		//当有了发送者地址、接受者地址、币值，对它们三者求Hash值
		txCopy.ID = txCopy.Hash()
		//txCopy.ID = txCopy.SetID()
		// 重新将其赋值为空，下次循环保存新的地址
		txCopy.Vin[inID].PubKey = nil
		//调用椭圆曲线加密算法函数，使用私钥对交易明文Hash做签名
		// 返回的r ，s就是签名后的数据
		r, s, err := ecdsa.Sign(rand.Reader, &privKey, txCopy.ID)
		if err != nil {
			log.Panic(err)
		}
		signature := append(r.Bytes(), s.Bytes()...)
		//将签名保存到输入中
		tx.Vin[inID].Signature = signature
	}

}

// 交易验证，返回bool
// 参数1 当前交易引用的前几笔交易
func (tx *Transaction) Verify(prevTXs map[string]Transaction) bool {
	// 1 创币交易不需要签名
	if tx.IsCoinbase() {
		return true
	}
	// 2 判断当前交易引用的前几笔交易是有效的
	for _, vin := range tx.Vin {
		if prevTXs[hex.EncodeToString(vin.Txid)].ID == nil {
			log.Panic("ERROR:引用的前几笔交易无效！")
		}
	}
	// txCopy的有效信息:币值，接受者，还差发送者信息
	txCopy := tx.TrimmedCopy()
	// 创建一个椭圆曲线
	curve := elliptic.P256()
	for inID, vin := range tx.Vin {
		//根据映射中的键得到值(值就是交易)
		prevTx := prevTXs[hex.EncodeToString(vin.Txid)]
		txCopy.Vin[inID].Signature = nil
		//保存的是发送者的地址
		txCopy.Vin[inID].PubKey = prevTx.Vout[vin.Vout].PubKeyHash
		//当有了发送者地址、接受者地址、币值，对它们三者求Hash值
		txCopy.ID = txCopy.Hash()
		//txCopy.ID = txCopy.SetID()
		// 重新将其赋值为空，下次循环保存新的地址
		txCopy.Vin[inID].PubKey = nil

		// 验证时，r、s的数据从签名中获取
		r := big.Int{}
		s := big.Int{}
		// 获取签名长度
		sigLen := len(vin.Signature)
		// 从签名数据中获取r.s
		r.SetBytes(vin.Signature[:sigLen/2])
		s.SetBytes(vin.Signature[sigLen/2:])

		x := big.Int{}
		y := big.Int{}
		//公钥数据的长度
		keyLen := len(vin.PubKey)
		// 从公钥中获取x,y
		x.SetBytes(vin.PubKey[:keyLen/2])
		y.SetBytes(vin.PubKey[keyLen/2:])

		// 根据公钥数据，和椭圆曲线，创建(椭圆曲线需要的)公钥对象
		rawPubKey := ecdsa.PublicKey{curve, &x, &y}
		//调用椭圆曲线算法的验证函数
		if ecdsa.Verify(&rawPubKey, txCopy.ID, &r, &s) == false {
			return false
		}

	}
	return true
}
