package main

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"log"
)

// 计算比特币地址时，使用的版本
const version = byte(0x00)

// 比特币地址校验和的长度
const addressChecksumLen = 4

// 钱包文件名称
const walletFile = "wallet.dat"

// 钱包类型(私钥公钥对)
type Wallet struct {
	PrivateKey ecdsa.PrivateKey //私钥
	PublicKey  []byte           //公钥
}

// 生成私钥公钥对的函数
func newKeyPair() (ecdsa.PrivateKey, []byte) {
	// 1 生成椭圆曲线
	curve := elliptic.P256()
	// 2 根据椭圆曲线和随机值生成一个私钥
	private, err := ecdsa.GenerateKey(curve, rand.Reader)
	if err != nil {
		log.Panic(err)
	}
	// 3 根据私钥生成公钥
	pubkey := append(private.PublicKey.X.Bytes(), private.PublicKey.Y.Bytes()...)
	// 4 返回私钥公钥对
	return *private, pubkey
}

// 创建钱包的函数
func NewWallet() *Wallet {
	private, public := newKeyPair()
	wallet := Wallet{private, public}
	return &wallet
}
