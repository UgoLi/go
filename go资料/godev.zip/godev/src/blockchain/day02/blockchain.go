package main

import (
	"log"

	"github.com/boltdb/bolt"
)

// 数据库文件
const dbFile = "blockchain.db"

// bucket表的名称
const blocksBucket = "blocks"

// 区块链的类型
type Blockchain struct {
	tip []byte   //最后一个块的Hash
	db  *bolt.DB //数据库对象
}

//为了实现对区块链的遍历，定义一个迭代器类型
type BlockchainIterator struct {
	currentHash []byte   //当前块的Hash
	db          *bolt.DB //数据库对象
}

// 为区块链类型添加方法，生成一个迭代器
func (bc *Blockchain) Iterator() *BlockchainIterator {
	bci := &BlockchainIterator{bc.tip, bc.db}
	return bci
}

// 为迭代器添加一个Next方法
func (i *BlockchainIterator) Next() *Block {
	var block *Block
	err := i.db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(blocksBucket))
		encodeBlock := b.Get(i.currentHash)
		block = DeserializeBlock(encodeBlock)
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
	i.currentHash = block.PrevBlockHash
	return block
}

// 新建一个区块链对象
func NewBlockchain() *Blockchain {
	var tip []byte
	// 新建数据库文件
	db, err := bolt.Open(dbFile, 0600, nil)
	if err != nil {
		log.Panic(err)
	}

	//数据的读写事务(匿名函数中完成具体的业务逻辑)
	err = db.Update(func(tx *bolt.Tx) error {
		//根据表的名称返回表对象
		b := tx.Bucket([]byte(blocksBucket))
		if b == nil {

			b, err := tx.CreateBucket([]byte(blocksBucket))
			if err != nil {
				log.Panic(err)
			}
			// 创建创世块
			genesis := NewGenesisBlock()
			// 将创世块保存到数据库中
			err = b.Put(genesis.Hash, genesis.Serialize())
			if err != nil {
				log.Panic(err)
			}
			// 将最后一个块的Hash保存到数据库中
			err = b.Put([]byte("l"), genesis.Hash)
			if err != nil {
				log.Panic(err)
			}
			tip = genesis.Hash
		} else {
			tip = b.Get([]byte("l"))
		}
		return nil
	})
	if err != nil {
		log.Panic(err)
	}

	bc := &Blockchain{tip, db}
	return bc

}

//在数据库中添加新块
func (bc *Blockchain) AddBlock(data string) {
	var lastHash []byte
	// 只读事务，读最新块的Hash
	err := bc.db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(blocksBucket))
		lastHash = b.Get([]byte("l"))
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
	// 创建新的区块对象
	newBlock := NewBlock(data, lastHash)
	//将新区块保存到数据库中
	err = bc.db.Update(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(blocksBucket))
		err := b.Put(newBlock.Hash, newBlock.Serialize())
		if err != nil {
			log.Panic(err)
		}
		err = b.Put([]byte("l"), newBlock.Hash)
		if err != nil {
			log.Panic(err)
		}
		bc.tip = newBlock.Hash
		return nil
	})
	if err != nil {
		log.Panic(err)
	}

}
