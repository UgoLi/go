package main

import (
	"flag"
	"fmt"
	"log"
	"os"
)

// 定义命令行接口类型
type CLI struct {
	//bc *Blockchain
}

// 1 创建区块链的方法(区块链初始化时调用的方法)
func (cli *CLI) createBlockchain(address string) {
	bc := CreateBlockchain(address)
	defer bc.db.Close()
	UTXOSet := UTXOSet{bc}
	UTXOSet.Reindex()
	fmt.Println("Done!")
}

// 2 获取指定地址的余额
func (cli *CLI) getBalance(address string) {
	if !ValidateAddress(address) {
		log.Panic("ERROR:无效的比特币地址！")
	}

	//读取数据库中最新块的Hash,创建区块链对象
	bc := NewBlockchain(address)
	// 创建未花费交易输出集对象
	UTXOSet := UTXOSet{bc}
	defer bc.db.Close()

	balance := 0
	//获取指定地址的未花费交易输出的集合
	// 将地址address解码得到编码前的三部分数据
	pubKeyHash := Base58Decode([]byte(address))
	// 得到中间部分，公钥Hash
	pubKeyHash = pubKeyHash[1 : len(pubKeyHash)-addressChecksumLen]
	//UTXOs := bc.FindUTXO(pubKeyHash)
	// 这是从UTXOSet数据中读取的数据，没有全链扫描
	UTXOs := UTXOSet.FindUTXO(pubKeyHash)
	for _, out := range UTXOs {
		balance += out.Value
	}
	fmt.Printf("Balance Of '%s':%d\n", address, balance)
}

// 3 打印使用方法
func (cli *CLI) printUsage() {
	fmt.Println("Usage:")
	fmt.Println("createwallet,创建钱包，并保存到文件")
	fmt.Println("listaddresses,打印所有地址")
	fmt.Println("createblockchain -address ADDRESS,区块链的初始化")
	fmt.Println("getbalance -address ADDRESS,获取指定地址的余额")
	fmt.Println("send -from FROM -to TO -amount AMOUNT,普通交易")
	fmt.Println("printchain,打印区块链信息")
}

// 4 参数验证，主要验证参数的个数
func (cli *CLI) validateArgs() {
	if len(os.Args) < 2 {
		cli.printUsage()
		os.Exit(1)
	}
}

//4 打印区块链信息
func (cli *CLI) printChain() {
	// 创建区块链对象
	bc := NewBlockchain("")
	// 关闭数据库
	defer bc.db.Close()
	// 获取区块链的迭代器
	bci := bc.Iterator()
	for {
		block := bci.Next()
		fmt.Printf("上一个块的Hash:%x\n", block.PrevBlockHash)
		//fmt.Printf("区块中交易数据：%s\n", block.Data)
		fmt.Printf("当前块Hash:%x\n", block.Hash)
		pow := NewProofOfWork(block)
		fmt.Printf("Pow:%v\n", pow.Validate())
		fmt.Println("\n")

		if len(block.PrevBlockHash) == 0 {
			break
		}
	}
}

// 5 普通交易
func (cli *CLI) send(from, to string, amount int) {

	bc := NewBlockchain(from)
	// 创建UTXO集对象
	UTXOSet := UTXOSet{bc}
	defer bc.db.Close()

	//构造普通交易(签名)
	//tx := NewUTXOTransaction(from, to, amount, bc)
	tx := NewUTXOTransaction(from, to, amount, &UTXOSet)
	// 增加一个创币交易(现在的逻辑是将挖矿奖励给交易的发送者)
	cbTx := NewCoinbaseTX(from, "")
	//调用挖矿函数产生新区块(验证)
	newBlock := bc.MineBlock([]*Transaction{cbTx, tx})
	// 未花费交易输出集
	UTXOSet.Update(newBlock)
	fmt.Println("Success!")
}

// 5 命令行接口类型的Run()方法，根据用户输入，调用相关函数
func (cli *CLI) Run() {
	// 参数个数的验证
	cli.validateArgs()

	// 1 创建子命令

	createBlockchainCmd := flag.NewFlagSet("createblockchain", flag.ExitOnError)
	getBalanceCmd := flag.NewFlagSet("getbalance", flag.ExitOnError)
	sendCmd := flag.NewFlagSet("send", flag.ExitOnError)
	// 2 为子命令添加参数
	createBlockchainAddress := createBlockchainCmd.String("address",
		"", "初始化区块链时，接收创世块的奖励的地址")
	getBalanceAddress := getBalanceCmd.String("address",
		"", "获取余额的地址")
	sendFrom := sendCmd.String("from", "", "发送者")
	sendTo := sendCmd.String("to", "", "接受者")
	sendAmount := sendCmd.Int("amount", 0, "币值")
	// 3 解析子命令参数
	switch os.Args[1] {
	case "createblockchain":
		err := createBlockchainCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	case "getbalance":
		err := getBalanceCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	case "send":
		err := sendCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	case "printchain":
		cli.printChain()
	case "createwallet":
		cli.createWallet()
	case "listaddresses":
		cli.listAddresses()
	default:
		cli.printUsage()
		os.Exit(1)
	}

	//4 判断如果完成命令解析，使用命令行参数
	// 4.1 初始化区块链
	if createBlockchainCmd.Parsed() {
		if *createBlockchainAddress == "" {
			createBlockchainCmd.Usage()
			os.Exit(1)
		}
		cli.createBlockchain(*createBlockchainAddress)
	}
	// 4.2 获取余额
	if getBalanceCmd.Parsed() {
		if *getBalanceAddress == "" {
			getBalanceCmd.Usage()
			os.Exit(1)
		}
		cli.getBalance(*getBalanceAddress)
	}
	// 4.3 交易
	if sendCmd.Parsed() {
		if *sendFrom == "" || *sendTo == "" || *sendAmount <= 0 {
			sendCmd.Usage()
			os.Exit(1)
		}
		cli.send(*sendFrom, *sendTo, *sendAmount)
	}

}
