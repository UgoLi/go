// 1 包声明 ，单行注释
package main

// 2 导入包,如果导入的包未被使用，将会导致语法错误
import (
	"fmt"
)

/* 多行注释，也叫做块注释
3 入口函数
*/
func main() {

	// 其它语言的语句以;结束，Go不需要;作为语句的结束
	fmt.Println("Hello 世界!")

}
