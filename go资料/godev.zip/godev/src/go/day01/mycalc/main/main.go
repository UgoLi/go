package main

import (
	"fmt"
	"go/day01/mycalc/math"
	"go/day01/mycalc/math2"
)

func main() {
	add := math.Add(5, 3)
	fmt.Println("add =", add)
	sub := math.Sub(5, 3)
	fmt.Println("sub =", sub)
	mul := math2.Mul(5, 3)
	fmt.Println("mul =", mul)
	//函数名称小写，包外不可见
	math2.Test()
}
