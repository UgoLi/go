// main
package main

func main() {
	// 1 创建包含创世块的区块链
	bc := NewBlockchain()
	// 4关闭数据库
	defer bc.db.Close()
	// 3  命令行接口
	cli := CLI{bc}
	cli.Run()

	/*
		// 2 添加新块
		bc.AddBlock("John send 1 BTC to Tom ")
		bc.AddBlock("zhangsan send 2 btc to lisi")
		bc.AddBlock("张飞 send 2 btc to 刘备")
		// 3 遍历
		// 3.1 创建迭代器
		bci := bc.Iterator()

		for {
			// 得到区块链中最新块
			block := bci.Next()
			fmt.Printf("*********区块数据**************\n")
			fmt.Printf("上一个区块的Hash：%x\n", block.PrevBlockHash)
			fmt.Printf("交易信息：%s\n", block.Data)
			fmt.Printf("当前块Hash:%x\n\n", block.Hash)

			if len(block.PrevBlockHash) == 0 {
				break
			}
		}
	*/

}
