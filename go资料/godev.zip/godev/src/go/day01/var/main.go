// main
package main

import (
	"fmt"
)

//包级别的变量(在同一个包中的所有函数都可以使用)
var age = 28

/*
score:=100//简短声明不能用于包级别的变量
*/
func main() {
	// 1 变量的一般声明格式
	var i int = 10
	// 2 简短声明
	j := 20
	// 3 多变量声明
	var a, b, c int = 10, 20, 30
	name, sage := "张三", 18
	// 4 变量没有初始化值时，系统都会设置默认"零值"
	var m, n int
	// 5 变量赋值
	m = 100
	n = 200
	m = m + 1 //一般赋值
	n += 1    //复合赋值
	fmt.Println(i, j, age, a, b, c, m, n, name, sage)

	// 6 使用多重赋值，交换两个变量的值
	fmt.Println("交换前:", m, n)
	m, n = n, m
	fmt.Println("交换后:", m, n)
	// 7  _标识符,一般用在多返回值函数中，不想保存某个返回值时，用_接收

}
