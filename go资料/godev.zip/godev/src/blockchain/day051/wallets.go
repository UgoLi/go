package main

import (
	"bytes"
	"crypto/elliptic"
	"encoding/gob"
	"fmt"
	"io/ioutil"
	"log"
	"os"
)

//钱包集合类型
type Wallets struct {
	//key是字符串表示的地址，value是钱包对象的指针
	Wallets map[string]*Wallet
}

// 向钱包集合中添加钱包的方法
func (ws *Wallets) CreateWallet() string {
	// 1 创建一个新钱包(包含了私钥公钥对)
	wallet := NewWallet()
	// 2 生成地址
	address := fmt.Sprintf("%s", wallet.GetAddress())
	// 3 以地址为键，钱包对象指针为值，添加到钱包集合中
	ws.Wallets[address] = wallet
	// 4 返回地址
	return address
}

//返回钱包集合中的所有地址
func (ws *Wallets) GetAddresses() []string {
	var addresses []string
	for address := range ws.Wallets {
		addresses = append(addresses, address)
	}
	return addresses
}

//在映射中根据键获取值，根据地址获取钱包对象
func (ws *Wallets) GetWallet(address string) Wallet {
	return *ws.Wallets[address]
}

// 将钱包集合的数据保存到文件中
func (ws *Wallets) SaveToFile() {
	// 定义一个(变长)缓冲区
	var content bytes.Buffer
	// 注册相关类型(Curve)
	gob.Register(elliptic.P256())
	// 创建一个编码器
	encoder := gob.NewEncoder(&content)
	// 对ws钱包集合编码，保存到content这个缓冲区中
	err := encoder.Encode(ws)
	if err != nil {
		log.Panic(err)
	}
	// 将content这个缓冲区中的数据写到文件中
	err = ioutil.WriteFile(walletFile, content.Bytes(), 0644)
	if err != nil {
		log.Panic(err)
	}
}

// 从文件中加载获取钱包集合对象
func (ws *Wallets) LoadFromFile() error {
	if _, err := os.Stat(walletFile); os.IsNotExist(err) {
		return err
	}
	// 读取文件内容
	fileContent, err := ioutil.ReadFile(walletFile)
	if err != nil {
		log.Panic(err)
	}
	var wallets Wallets
	//注册curve类型
	gob.Register(elliptic.P256())
	// 创建一个解码器
	decoder := gob.NewDecoder(bytes.NewReader(fileContent))
	// 对文件内容解码，保存到钱包集合这个对象中
	err = decoder.Decode(&wallets)
	if err != nil {
		log.Panic(err)
	}
	// 将解码后的数据保存到ws中
	ws.Wallets = wallets.Wallets
	return nil

}
func NewWallets() (*Wallets, error) {
	// 1 创建钱包集合对象
	wallets := Wallets{}
	// 2 创建一个映射
	wallets.Wallets = make(map[string]*Wallet)
	// 3 加载文件得到映射数据
	err := wallets.LoadFromFile()
	// 4 返回
	return &wallets, err
}
