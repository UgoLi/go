package main

import (
	"bytes"
	"crypto/sha256"
	"fmt"
	"math"
	"math/big"
)

var (
	maxNonce = math.MaxInt64
)

// 定义挖矿的难度值
const targetBits = 20 //十六进制的前6位为零

// 定义工作量证明类型
type ProofOfWork struct {
	block  *Block   //区块的指针
	target *big.Int //目标数值
}

// 创建工作量证明对象
func NewProofOfWork(b *Block) *ProofOfWork {
	//产生一个大整数对象，初始值为1
	target := big.NewInt(1)
	// 左移操作，产生一个目标值
	target.Lsh(target, uint(256-targetBits))
	// 创建工作量证明对象
	pow := &ProofOfWork{b, target}
	//返回工作量证明对象
	return pow
}

// 准备要计算的数据
func (pow *ProofOfWork) prepareData(nonce int) []byte {
	data := bytes.Join(
		[][]byte{
			pow.block.PrevBlockHash,
			pow.block.Data,
			IntToHex(pow.block.Timestamp),
			IntToHex(int64(targetBits)),
			IntToHex(int64(nonce)),
		},
		[]byte{},
	)
	return data

}

// 工作量证明的计算
func (pow *ProofOfWork) Run() (int, []byte) {
	var hashInt big.Int
	var hash [32]byte
	nonce := 0
	fmt.Printf("Mining the block containing %s\n", pow.block.Data)

	//防止整数溢出
	for nonce < maxNonce {
		//准备数据
		data := pow.prepareData(nonce)
		//计算区块的Hash值
		hash = sha256.Sum256(data)
		fmt.Printf("\r%x", hash)
		//将计算得到的Hash值转换为一个大整数hashInt
		hashInt.SetBytes(hash[:])
		//比较
		if hashInt.Cmp(pow.target) == -1 {
			break
		} else {
			nonce++
		}
	}
	fmt.Println("\n")
	return nonce, hash[:]
}

// 验证Hash值是否满足要求
func (pow *ProofOfWork) Validate() bool {
	var hashInt big.Int
	data := pow.prepareData(pow.block.Nonce)
	hash := sha256.Sum256(data)
	hashInt.SetBytes(hash[:])
	isValid := hashInt.Cmp(pow.target) == -1
	return isValid

}
