// main
package main

import (
	"go/day08/rpc/server/rpcserver"
	"log"
	"net"
	"net/http"
	"net/rpc"
	"os"
)

func main() {
	// 1 定义服务提供的对象
	arith := new(rpcserver.Arith)
	// 2 注册对象并公布了公开的方法
	rpc.Register(arith)
	// 3 将rpc绑定到HTTP协议上
	rpc.HandleHTTP()
	// 4 开启服务
	l, err := net.Listen("tcp", ":1234")
	if err != nil {
		log.Fatal("listen error", err)
	}
	// 5 处理客户端请求
	go http.Serve(l, nil)

	os.Stdin.Read(make([]byte, 1))

}
