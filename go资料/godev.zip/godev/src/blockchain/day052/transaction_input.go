package main

import (
	"bytes"
)

//交易输入类型
type TXInput struct {
	Txid      []byte //引用的输出所对应的交易的ID
	Vout      int    //交易输出在交易中的索引值
	Signature []byte //交易签名
	PubKey    []byte //公钥
}

func (in *TXInput) UseKey(pubKeyHash []byte) bool {
	// 根据输入中的公钥计算得到公钥hash
	lockingHash := HashPubKey(in.PubKey)
	// 比较参数表示的公钥和输入计算的公钥
	return bytes.Compare(lockingHash, pubKeyHash) == 0
}
