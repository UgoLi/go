package main

import "fmt"

// 常量声明时，可以限定类型，也不可以不限定类型
const PI = 3.14
const hello = "Hello World"
const num int = 100

// 常量的批量赋值
const (
	a = iota
	b
	c
)

const (
	d1 = 1
	d2
	d3 = 2
	d4
	d5
)

// 使用iota定义一个星期这样的枚举数据

func main() {
	//a = 0 //不能对常量重新赋值
	fmt.Println(PI, hello, num)
	fmt.Println(a, b, c)
	fmt.Println(d1, d2, d3, d4, d5)
	// 常量赋值还可以使用常量表达式
	const number = 1 << 3
	fmt.Println(number)
}
