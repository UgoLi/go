// main
package main

import (
	"fmt"
	"unsafe"
)

// 1 浮点类型
func UseFloat() {
	var f1 float32
	f1 = 12.5
	fmt.Println(f1)
	f2 := 0.5 //自动推断类型为float64
	fmt.Println(f2)
	f1 = float32(f2)    //强制转换
	fmt.Println(f1, f2) // f1占4个字节，f2占8个字节
	fmt.Println(unsafe.Sizeof(f1), unsafe.Sizeof(f2))
	// 浮点数比较，永远不能使用 ==
	// 科学计数法
	f3 := 1.99e+3
	f4 := 1.99e-3
	fmt.Println(f3, f4)
}

// 2 complex的演示
func UseComplex() {
	var c1 complex128
	c1 = 10 + 5i
	c2 := 2 + 5i //自动推断为complex128
	fmt.Println(c1, c2, c1+c2)
	//分别输出c1、c2的实部和c1、c2的虚部
	fmt.Println(real(c1), real(c2), imag(c1), imag(c2))
}

// 3 布尔类型(与零或非零没有关系，不能赋值)
func UseBool() {
	var bFlag bool = true
	fmt.Println(bFlag)
	var IsCancel bool
	fmt.Println(IsCancel)

}

// 4 字符串类型
func UseString() {
	var str1 string = "Hello"
	fmt.Println(str1)
	str2 := " World"
	// 1 字符串连接
	fmt.Println(str1 + str2)
	// 2 字符串占用的字节数
	fmt.Println(len(str1))
	// 3 截取子串(左闭右开)
	fmt.Println(str1[1:3], str1[:3], str1[3:], str1[:])
	// 4 字符串中字符不可修改
	//str1[0] = "h"
	// 只能整体重新对字符串赋值
	str1 = "hello"
	fmt.Println(str1)

}
func main() {
	//UseFloat()
	//UseComplex()
	//UseBool()
	UseString()

}
