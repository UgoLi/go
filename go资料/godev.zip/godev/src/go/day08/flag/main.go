// main
package main

import (
	"flag"
	"fmt"
	"os"
)

// os.Args[0]、os.Args[1]、os.Args[2]
// flag.exe adduser -name 张三 -age 20 -balance 23.6 -single=false
func main() {
	// 1 定义子命令
	addCmd := flag.NewFlagSet("adduser", flag.ExitOnError)
	// 2 为子命令添加参数
	data1 := addCmd.String("name", "", "请输入姓名！")
	data2 := addCmd.Int("age", 18, "请输入年龄！")
	data3 := addCmd.Float64("balance", 0, "请输入余额！")
	data4 := addCmd.Bool("single", false, "是否单身？")
	if len(os.Args) < 7 {
		addCmd.Usage()
		return
	}

	// 3 解析参数
	addCmd.Parse(os.Args[2:])
	// 4 判断如果解析成功，使用参数
	if addCmd.Parsed() {
		fmt.Printf("data1=%v\n", *data1)
		fmt.Printf("data2=%v\n", *data2)
		fmt.Printf("data3=%v\n", *data3)
		fmt.Printf("data4=%v\n", *data4)

	}

}
