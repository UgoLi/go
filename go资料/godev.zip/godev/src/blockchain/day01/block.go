// main
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/gob"
	"log"

	"strconv"
	"time"
)

// 区块的类型
type Block struct {
	Timestamp     int64  //当前块的时间戳，表示区块创建的时间
	Data          []byte //区块中的交易信息
	PrevBlockHash []byte //上一个区块的Hash
	Hash          []byte //当前块的Hash
}

// 计算当前块的Hash(Block类型的方法)
func (b *Block) SetHash() {
	timestamp := []byte(strconv.FormatInt(b.Timestamp, 10))
	headers := bytes.Join([][]byte{b.PrevBlockHash, b.Data, timestamp}, []byte{})
	hash := sha256.Sum256(headers)
	b.Hash = hash[:]
}

// 创建区块的函数
func NewBlock(data string, prevBlockHash []byte) *Block {
	block := &Block{time.Now().Unix(), []byte(data), prevBlockHash, []byte{}}
	block.SetHash()
	return block
}

// 创建创世块的函数
func NewGenesisBlock() *Block {
	return NewBlock("Genesis Block", []byte{})
}

// 区块的序列化
func (b *Block) Serialize() []byte {
	// 1 定义一个buff对象
	var result bytes.Buffer
	// 2 使用Buff初始化一个编码器
	encoder := gob.NewEncoder(&result)
	// 3 使用编码器序列化Block对象
	err := encoder.Encode(b)
	if err != nil {
		log.Panic(err)
	}
	// 4 返回编码后的字节序列
	return result.Bytes()
}
func Deserialize(data []byte) *Block {
	var block Block
	// 创建以data这个字节序列为数据的一个解码器
	decoder := gob.NewDecoder(bytes.NewReader(data))
	// 解码
	err := decoder.Decode(&block)
	if err != nil {
		log.Panic(err)
	}
	return &block
}
