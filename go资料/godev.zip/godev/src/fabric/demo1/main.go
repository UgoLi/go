// main
package main

import (
	"fmt"
	"strconv"
)

// 选课类型
type ChooseCourse struct {
	CousrseNumber string //开课编号
	StudentId     string //学生Id
	Confirm       bool   //是否确认
}

func main() {
	//选课对象
	cc := ChooseCourse{"cs101", 123, true}

	//1 创建组合键
	key1, _ := stub.CreateCompositeKey("ChooseCourse",
		[]string{cc.CousrseNumber, strconv.Itoa(cc.StudentId)})
	//2 使用
	stub.PutState(key1,[]byte(...))
	//3 拆分组合键  "ChooseCoursecs101123",
	//  objectType:ChooseCoursec []attrArray{"cs101","123"}
	objectType,attrArray,_:=stub.SplitCompositeKey(key1)
	// 4 部分组合键查询
	iterator,_:=stub.GetStateByPartialCompositeKey("ChooseCourse",[]string{"cs101"})
		

}
