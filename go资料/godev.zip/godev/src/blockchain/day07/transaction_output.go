package main

import (
	"bytes"
	"encoding/gob"
	"log"
)

//交易输出类型
type TXOutput struct {
	Value      int    //币值
	PubKeyHash []byte //公钥Hash
}

func (out *TXOutput) IsLockedWithKey(pubkeyHash []byte) bool {
	return bytes.Compare(out.PubKeyHash, pubkeyHash) == 0
}
func (out *TXOutput) Lock(address []byte) {
	//解码后，包含公钥Hash的三部分之和
	pubKeyHash := Base58Decode(address)
	//取中间的第二部分，公钥Hash
	pubKeyHash = pubKeyHash[1 : len(pubKeyHash)-addressChecksumLen]
	// 将公钥Hash保存到out对象的成员中
	out.PubKeyHash = pubKeyHash

}

// 创建新的交易输出对象
func NewTXOutput(value int, address string) *TXOutput {
	// 创建对象
	txo := &TXOutput{value, nil}
	// 将比特币地址计算得到公钥Hash，并保存到输入对象的字段中
	txo.Lock([]byte(address))
	return txo
}

// 未花费交易输出集合
type TXOutputs struct {
	Outputs []TXOutput //TXOutput的切片
}

// 未花费交易输出集的序列化
func (outs TXOutputs) Serialize() []byte {
	var buff bytes.Buffer
	enc := gob.NewEncoder(&buff)
	err := enc.Encode(outs)
	if err != nil {
		log.Panic(err)
	}
	return buff.Bytes()

}
func DeserializeOutputs(data []byte) TXOutputs {
	var outputs TXOutputs
	dec := gob.NewDecoder(bytes.NewReader(data))
	err := dec.Decode(&outputs)
	if err != nil {
		log.Panic(err)
	}
	return outputs
}
