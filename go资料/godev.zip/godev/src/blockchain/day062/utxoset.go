package main

import (
	"encoding/hex"
	"log"

	"github.com/boltdb/bolt"
)

//用于存储UTXOSet的表的名称
const utxoBucket = "chainstate"

// 定义未花费交易输出集类型
type UTXOSet struct {
	Blockchain *Blockchain
}

// 遍历整个区块链，获取相关的数据构造UTXOSet
// 在创建区块链的同时，就会创建UTXOSet对象，所以在cli的createBlockchain中被调用
func (u UTXOSet) Reindex() {
	// 1 获取数据对象
	db := u.Blockchain.db
	// 2 表的名称(用[]byte)
	bucketName := []byte(utxoBucket)
	// 3 读写事务
	err := db.Update(func(tx *bolt.Tx) error {
		// 3.1 先删除统一名称的现有表
		err := tx.DeleteBucket(bucketName)
		if err != nil && err != bolt.ErrBucketNotFound {
			log.Panic(err)
		}
		// 3.2 创建新表
		_, err = tx.CreateBucket(bucketName)
		if err != nil {
			log.Panic(err)
		}
		return nil

	})
	if err != nil {
		log.Panic(err)
	}
	// 4 获取未花费交易输出(以交易ID为键，未花费交易输出集合为值?)
	UTXO := u.Blockchain.FindUTXO()
	// 5 将未花费交易输出写到表中
	err = db.Update(func(tx *bolt.Tx) error {
		b := tx.Bucket(bucketName)
		// 遍历UTXO
		for txID, outs := range UTXO {
			key, err := hex.DecodeString(txID)
			if err != nil {
				log.Panic(err)
			}
			// 以交易ID为键，以outs为值保存(?)
			err = b.Put(key, outs.Serialize())
			if err != nil {
				log.Panic(err)
			}
		}
		return nil
	})

}
