package main

import (
	"encoding/hex"
	"fmt"
	"log"
	"os"

	"github.com/boltdb/bolt"
)

// 数据库文件
const dbFile = "blockchain.db"

// bucket表的名称
const blocksBucket = "blocks"

// 区块链的类型
type Blockchain struct {
	tip []byte   //最后一个块的Hash
	db  *bolt.DB //数据库对象
}

//为了实现对区块链的遍历，定义一个迭代器类型
type BlockchainIterator struct {
	currentHash []byte   //当前块的Hash
	db          *bolt.DB //数据库对象
}

// 为区块链类型添加方法，生成一个迭代器
func (bc *Blockchain) Iterator() *BlockchainIterator {
	bci := &BlockchainIterator{bc.tip, bc.db}
	return bci
}

// 为迭代器添加一个Next方法
func (i *BlockchainIterator) Next() *Block {
	var block *Block
	err := i.db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(blocksBucket))
		encodeBlock := b.Get(i.currentHash)
		block = DeserializeBlock(encodeBlock)
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
	i.currentHash = block.PrevBlockHash
	return block
}

// 读取数据库中最后一个块的Hash，创建区块链对象(要求数据库已经存在)
func NewBlockchain(address string) *Blockchain {
	if dbExists() == false {
		fmt.Println("找不到数据库文件！")
		os.Exit(1)
	}
	var tip []byte
	// 打开数据库文件
	db, err := bolt.Open(dbFile, 0600, nil)
	if err != nil {
		log.Panic(err)
	}
	err = db.View(func(tx *bolt.Tx) error {
		// 获取表对象
		b := tx.Bucket([]byte(blocksBucket))
		// 获取blocks表中存储的最后一个块的Hash
		tip = b.Get([]byte("l"))
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
	//创建区块链对象
	bc := Blockchain{tip, db}
	return &bc
}

// 创建新的数据库文件，保存创世块，并创建区块链对象(要求数据库不存在)
func CreateBlockchain(address string) *Blockchain {
	if dbExists() {
		fmt.Println("数据库已经存在！")
		os.Exit(1)
	}
	var tip []byte
	// 新建一个数据库文件
	db, err := bolt.Open(dbFile, 0600, nil)
	if err != nil {
		log.Panic(err)
	}
	// 读写事务
	err = db.Update(func(tx *bolt.Tx) error {
		// 创建创币交易
		cbtx := NewCoinbaseTX(address, "创世块数据")
		// 创建创世块
		genesis := NewGenesisBlock(cbtx)
		// 创建blocks表
		b, err := tx.CreateBucket([]byte(blocksBucket))
		if err != nil {
			log.Panic(err)
		}
		// 保存创世块数据
		err = b.Put(genesis.Hash, genesis.Serialize())
		if err != nil {
			log.Panic(err)
		}
		// 保存最后一个块的Hash
		err = b.Put([]byte("l"), genesis.Hash)
		if err != nil {
			log.Panic(err)
		}
		// 保存最后一个块的Hash
		tip = genesis.Hash

		return nil

	})
	if err != nil {
		log.Panic(err)
	}
	// 创建区块链对象
	bc := Blockchain{tip, db}
	return &bc
}
func dbExists() bool {
	// Stat返回文件状态，如果文件不存在，返回false
	if _, err := os.Stat(dbFile); os.IsNotExist(err) {
		return false
	}
	// 文件存在，返回true
	return true
}

/*
//在数据库中添加新块
func (bc *Blockchain) AddBlock(data string) {
	var lastHash []byte
	// 只读事务，读最新块的Hash
	err := bc.db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(blocksBucket))
		lastHash = b.Get([]byte("l"))
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
	// 创建新的区块对象
	newBlock := NewBlock(data, lastHash)
	//将新区块保存到数据库中
	err = bc.db.Update(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(blocksBucket))
		err := b.Put(newBlock.Hash, newBlock.Serialize())
		if err != nil {
			log.Panic(err)
		}
		err = b.Put([]byte("l"), newBlock.Hash)
		if err != nil {
			log.Panic(err)
		}
		bc.tip = newBlock.Hash
		return nil
	})
	if err != nil {
		log.Panic(err)
	}

}
*/
// 查找指定地址的包含未花费交易输出的交易
func (bc *Blockchain) FindUnspentTransactions(pubKeyHash []byte) []Transaction {
	// 定义一个切片保存未花费交易输出的交易
	var unspentTXs []Transaction
	// 已花费交易输出（采用映射保存，键是交易的ID，[]int{已花费的输出的索引值}）
	spentTXOs := make(map[string][]int)
	// 开始遍历
	bci := bc.Iterator()
	// 遍历区块链，获取每一个区块
	for {
		block := bci.Next()
		//遍历区块获取每一笔交易
		for _, tx := range block.Transactions {
			txID := hex.EncodeToString(tx.ID)
		Outputs:
			//遍历交易，获取每一个交易中的输出
			for outIdx, out := range tx.Vout {
				// 输出是否被花费
				if spentTXOs[txID] != nil {
					for _, spentOut := range spentTXOs[txID] {
						if spentOut == outIdx {
							continue Outputs

						}
					}
				} //if
				//获取指定地址的包含未花费输出的交易
				if out.IsLockedWithKey(pubKeyHash) {
					unspentTXs = append(unspentTXs, *tx)
				}
			} //for outIdx

			// 不是创币交易，因为创币交易没有输入
			if tx.IsCoinbase() == false {
				// 遍历交易输入
				for _, in := range tx.Vin {
					//如果是指定地址的交易
					if in.UseKey(pubKeyHash) {
						// 输入引用的交易ID
						inTxID := hex.EncodeToString(in.Txid)
						//map[tx0]=[]int{0},map[tx3]=[]int{1}
						spentTXOs[inTxID] = append(spentTXOs[inTxID], in.Vout)
					}
				}
			}

		} // for tx
		if len(block.PrevBlockHash) == 0 {
			break
		}

	}

	return unspentTXs

}

//返回指定地址的所有未花费交易输出(为求余额服务)
func (bc *Blockchain) FindUTXO(pubKeyHash []byte) []TXOutput {
	var UTXOs []TXOutput
	unspentTransactions := bc.FindUnspentTransactions(pubKeyHash)
	for _, tx := range unspentTransactions {
		for _, out := range tx.Vout {
			//因为有地址作为限定条件，所以，添加进去的一定是UXTO
			// 因为在同一交易中，不会出现地址相同的两个输出
			if out.IsLockedWithKey(pubKeyHash) {
				UTXOs = append(UTXOs, out)
			}
		}
	}
	return UTXOs
}

// 返回可花费的交易输出(以交易ID和输出的索引值表示map[txid]=[]int{0,1,...})
// 为普通交易提供服务
func (bc *Blockchain) FindSpendableOutputs(pubKeyHash []byte, amount int) (int, map[string][]int) {
	//定义返回值变量
	unspentOutputs := make(map[string][]int)
	accumulated := 0
	unspentTXs := bc.FindUnspentTransactions(pubKeyHash)
Work:
	for _, tx := range unspentTXs {
		txID := hex.EncodeToString(tx.ID)
		for outIdx, out := range tx.Vout {
			if out.IsLockedWithKey(pubKeyHash) && accumulated < amount {
				accumulated += out.Value
				unspentOutputs[txID] = append(unspentOutputs[txID], outIdx)
				if accumulated >= amount {
					break Work
				}
			}

		}
	}
	return accumulated, unspentOutputs

}

// 增加MineBlock函数
func (bc *Blockchain) MineBlock(transactions []*Transaction) {
	var lastHash []byte
	//只读事务
	err := bc.db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(blocksBucket))
		lastHash = b.Get([]byte("l"))
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
	// 产生新块
	newBlock := NewBlock(transactions, lastHash)
	//读写事务，将新块添加到数据库
	err = bc.db.Update(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(blocksBucket))
		// 添加新块
		err := b.Put(newBlock.Hash, newBlock.Serialize())
		if err != nil {
			log.Panic(err)
		}
		//保存新块的hash
		err = b.Put([]byte("l"), newBlock.Hash)
		if err != nil {
			log.Panic(err)
		}
		bc.tip = newBlock.Hash
		return nil
	})
	if err != nil {
		log.Panic(err)
	}
}
