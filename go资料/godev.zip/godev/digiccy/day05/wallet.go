package main

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"log"

	"golang.org/x/crypto/ripemd160"
)

const version = byte(0x00)      //版本，为生成地址做准备
const walletFile = "wallet.dat" //钱包文件名称
const addressChecksumLen = 4    //校验和

// 钱包类型(包括私钥和公钥)
type Wallet struct {
	PrivateKey ecdsa.PrivateKey
	PublicKey  []byte
}

// 创建钱包对象的函数
func NewWallet() *Wallet {
	private, public := newKeyPair()
	wallet := Wallet{private, public}

	return &wallet
}

//在钱包类型中添加生成地址的方法
func (w Wallet) GetAddress() []byte {
	// 1 公钥Hash
	pubKeyHash := HashPubKey(w.PublicKey)
	// 2 版本+公钥Hash
	versionedPayload := append([]byte{version}, pubKeyHash...)
	// 3 生成校验和
	checksum := checksum(versionedPayload)
	// 4 版本+公钥Hash+校验和
	fullPayload := append(versionedPayload, checksum...)
	// 5 进行base58编码，生成地址
	address := Base58Encode(fullPayload)
	// 6 返回地址
	return address
}

// HashPubKey hashes public key
func HashPubKey(pubKey []byte) []byte {
	publicSHA256 := sha256.Sum256(pubKey)

	RIPEMD160Hasher := ripemd160.New()
	_, err := RIPEMD160Hasher.Write(publicSHA256[:])
	if err != nil {
		log.Panic(err)
	}
	publicRIPEMD160 := RIPEMD160Hasher.Sum(nil)

	return publicRIPEMD160
}

// 验证地址的有效性
func ValidateAddress(address string) bool {
	pubKeyHash := Base58Decode([]byte(address))
	actualChecksum := pubKeyHash[len(pubKeyHash)-addressChecksumLen:]
	version := pubKeyHash[0]
	pubKeyHash = pubKeyHash[1 : len(pubKeyHash)-addressChecksumLen]
	targetChecksum := checksum(append([]byte{version}, pubKeyHash...))

	return bytes.Compare(actualChecksum, targetChecksum) == 0
}

// Checksum generates a checksum for a public key
func checksum(payload []byte) []byte {
	firstSHA := sha256.Sum256(payload)
	secondSHA := sha256.Sum256(firstSHA[:])

	return secondSHA[:addressChecksumLen]
}

// 根据椭圆曲线，生成私钥公钥对
func newKeyPair() (ecdsa.PrivateKey, []byte) {
	// 1 生成椭圆曲线
	curve := elliptic.P256()
	// 2 使用椭圆曲线生成私钥
	private, err := ecdsa.GenerateKey(curve, rand.Reader)
	if err != nil {
		log.Panic(err)
	}
	// 3由私钥生成公钥
	pubKey := append(private.PublicKey.X.Bytes(), private.PublicKey.Y.Bytes()...)
	// 4 返回秘钥对
	return *private, pubKey
}
