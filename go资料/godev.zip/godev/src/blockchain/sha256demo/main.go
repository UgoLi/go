// main
package main

import (
	"crypto/sha256"
	"fmt"
)

func main() {
	hashValue := sha256.Sum256([]byte("Hello World"))
	hashValue2 := sha256.Sum256([]byte("HelloWorld"))
	fmt.Println(hashValue == hashValue2)
}
