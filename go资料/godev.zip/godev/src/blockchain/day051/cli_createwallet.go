package main

import (
	"fmt"
)

func (cli *CLI) createWallet() {
	// 1 创建钱包集合这个对象
	wallets, _ := NewWallets()
	// 2 创建私钥公钥对，并将钱包对象保存到钱包集合中，返回地址
	address := wallets.CreateWallet()
	// 3 将最新的钱包集合数据保存到文件中
	wallets.SaveToFile()
	fmt.Printf("新的比特币地址：%s\n", address)

}
