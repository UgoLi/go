package main

import (
	"flag"
	"fmt"
	"log"
	"os"
)

// 定义命令行接口类型
type CLI struct {
	bc *Blockchain
}

// 1 使用方法
func (cli *CLI) printUsage() {
	fmt.Println("Usage:")
	fmt.Println("addblock -data BLOCK DATA,添加新区块到区块链")
	fmt.Println("printchain,打印区块链信息")
}

// 2 参数验证，主要验证参数的个数
func (cli *CLI) validateArgs() {
	if len(os.Args) < 2 {
		cli.printUsage()
		os.Exit(1)
	}
}

// 3 添加新区块
func (cli *CLI) addBlock(data string) {
	cli.bc.AddBlock(data)
	fmt.Println("Success!")
}

//4 打印区块链信息
func (cli *CLI) printChain() {
	bci := cli.bc.Iterator()
	for {
		block := bci.Next()
		fmt.Printf("上一个块的Hash:%x\n", block.PrevBlockHash)
		fmt.Printf("区块中交易数据：%s\n", block.Data)
		fmt.Printf("当前块Hash:%x\n", block.Hash)
		pow := NewProofOfWork(block)
		fmt.Printf("Pow:%v\n", pow.Validate())
		fmt.Println("\n")

		if len(block.PrevBlockHash) == 0 {
			break
		}
	}
}

// 5 命令行接口类型的Run()方法，根据用户输入，调用相关函数
func (cli *CLI) Run() {
	// 参数个数的验证
	cli.validateArgs()

	// 创建子命令
	addBlockCmd := flag.NewFlagSet("addblock", flag.ExitOnError)
	addBlockData := addBlockCmd.String("data", "", "Block Data")

	switch os.Args[1] {
	case "addblock":
		//解析子命令参数
		err := addBlockCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	case "printchain":
		cli.printChain()
	default:
		cli.printUsage()
		os.Exit(1)
	}
	//如果已经解析
	if addBlockCmd.Parsed() {
		if *addBlockData == "" {
			addBlockCmd.Usage()
			os.Exit(1)
		}
		cli.addBlock(*addBlockData)
	}

}
